# E-Commerce Sales Insights Analysis | Power BI

An interactive business intelligence project built with **Microsoft Power BI** to explore e-commerce sales performance, profitability, product performance, shipping patterns, and regional trends.

## Project Overview

This project transforms e-commerce sales data into an interactive dashboard to support data-driven business decisions. The Power BI report includes KPI reporting, category and geography analysis, product rankings, regional performance, and shipping-type comparisons.

## Dashboard Highlights

- **Sales by Category** – compare sales performance across product categories.
- **Sales by States** – explore the geographic distribution of sales.
- **Top 5 Products by YTD Sales** – identify the leading products.
- **Bottom 5 Products by YTD Sales** – identify products with the lowest year-to-date sales.
- **YTD Sales by Region** – compare sales across regions.
- **YTD Sales by Shipping Type** – understand sales distribution by shipping method.

The project documentation also describes KPIs such as Total Sales, Total Profit, Total Quantity, and Profit Margin %, along with monthly trends and forecasting.

## Tools & Techniques

- Microsoft Power BI Desktop
- Power Query for data preparation and transformation
- DAX for measures and calculations
- Interactive report visuals, filters, and geographic analysis

## Repository Structure

```text
Ecommerce_Sales_Insights/
├── dashboard/
│   └── Ecommerce_Sales_Insights.pbix
├── data/
│   ├── Ecommerce_data.csv
│   └── Longitude&Latitude_data.csv
├── documentation/
└── README.md
```

## How to Open the Project

1. Download `dashboard/Ecommerce_Sales_Insights.pbix` from this repository.
2. Install and open **Microsoft Power BI Desktop**.
3. Open the downloaded PBIX file.
4. If Power BI asks for data-source paths, update them to the CSV files in the `data` folder, then refresh the report.

> GitHub displays the project documentation and files. It does not render a PBIX report as an interactive dashboard in the browser. To share an interactive browser-based report, publish it through Power BI Service and grant the viewer appropriate access. Do not use a public sharing option for confidential data.

## Project Objective

To analyze e-commerce business performance, identify sales and profitability patterns, compare product and regional results, and present insights in an accessible dashboard.

## Author

**Add your name here**  
Power BI | Data Analytics Project
